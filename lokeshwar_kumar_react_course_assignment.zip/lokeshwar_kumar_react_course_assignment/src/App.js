import React from 'react';
import logo from './logo.svg';
import './App.css';
import Content from './Content/Content.react';

function App() {
  return (
    <div className="App">
      <Content></Content>
    </div>
  );
}

export default App;
